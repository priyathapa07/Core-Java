package Revision;
/**
 * child class
 * polymorphism
 */

import java.util.Date;

public class Manager extends Employee {
    public String division;
    public Date contractExpiryDate;
}
