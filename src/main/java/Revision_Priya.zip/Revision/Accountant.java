package Revision;

/**
 * child class
 * using it for polymorphism
 */

public class Accountant extends Employee{
   public String level, designation;
   public Double salary;

}
