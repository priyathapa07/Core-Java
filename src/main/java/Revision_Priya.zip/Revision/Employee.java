package Revision;

/**
 * polymorphism
 */

//Parent CLass
public class Employee {
    public String name,address,department;
    public int phoneNum,emailId;

}
